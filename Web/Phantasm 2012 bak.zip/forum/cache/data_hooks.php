<?php
$expired = (time() > 1262374720) ? true : false;
if ($expired) { return; }

$data = unserialize('a:0:{}');

?>